import React from 'react';
export default function App() {
    return (
        <div>Good luck building TripsApp UI using React</div>
    )
}