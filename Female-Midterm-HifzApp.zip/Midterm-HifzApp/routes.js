const express = require('express');
const router = express.Router();

const hifzService = require('./services/HifzService');

//ToDo: Implement Hifz Web API


module.exports = router;