const fs = require('fs-extra');
const path = require('path');
const surahFilePath = path.join(__dirname, '../data/surah.json');
const hifzFilePath = path.join(__dirname, '../data/hifz-register.json');
const studentFilePath = path.join(__dirname, '../data/student.json');

class HifzRepository {
    //ToDo: Implement Hifz Repository
}

module.exports = new HifzRepository();