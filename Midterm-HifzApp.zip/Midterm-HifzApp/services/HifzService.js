const hifzRepo = require('../repositories/HifzRepository');

class HifzService {
//ToDo: Implement Hifz Service
}

module.exports = new HifzService();